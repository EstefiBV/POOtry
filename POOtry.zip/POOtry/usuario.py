from datetime import datetime
class Usuario:
    def __init__(self, nombre):
        self.nombre = nombre

    def mostrar_ingreso(self):
        fecha = datetime.now()
        print("Usuario: ", self.nombre)
        print("Ingreso: ", fecha.strftime("%d/%m/%Y %H:%M"))