from operacion import Operaciones

usuario = input("Digite el nombre del usuario: ")
descripcion = input("Digite la descripción de la operación: ")

operacion1 = Operaciones(usuario, descripcion)
operacion1.mostrar_operacion()