from datetime import datetime

class Operaciones:
    def __init__(self, usuario, descripcion):
        self.usuario = usuario
        self.descripcion = descripcion
        self.fecha = datetime.now()

    def mostrar_operacion(self):
        print("==== OPERACIÓN REGISTRADA ====")
        print("Ussuario: ", self.usuario)
        print("Descripción: ", self.descripcion)
        print("Hora: ", self.fecha.strftime("%H:%M"))