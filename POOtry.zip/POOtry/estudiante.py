class Estudiante:

    def __init__(self, nombre, nota1, nota2):
        self.nombre = nombre
        self.nota1 = nota1
        self.nota2 = nota2

    def calcular_promedio(self):
        promedio = (self.nota1 + self.nota2) / 2
        return promedio
    
    def verificar_estado(self):
        promedio = self.calcular_promedio()
        if promedio >= 70:
            return "Aprobado"
        else:
            return "Reprobado"
        
    def mostrar_reporte(self):
        print("===== REPORTE DEL ESTUDIANTE ====")
        print("Nombre: ", self.nombre)
        print("Nota 1: ", self.nota1)
        print("Nota 2: ", self.nota2)
        print("Promedio: ", self.calcular_promedio())
        print("Estado: ", self.verificar_estado())



