class Persona:

    def __init__(self, nombre):
        self.nombre = nombre

    def mostrar_nombre(self):
        print("Nombre actual: ", self.nombre)

    def cambiarNombre(self, nuevo):
        self.nombre = nuevo